--------------Email templates

All the emails are available in relevant folder, Just copy and paste in email templates settings from admin dashboard for each email.

For more information you can contact us at our support forum : https://amentotech.ticksy.com/